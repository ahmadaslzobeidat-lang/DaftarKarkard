package com.example.daftarkarkard

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(18, 59, 53)
        window.navigationBarColor = Color.rgb(18, 59, 53)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(243, 246, 245))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.databaseEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?, url: android.webkit.WebResourceRequest?
                ): android.webkit.WebResourceResponse? {
                    return url?.url?.let { assetLoader.shouldInterceptRequest(it) }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                    val shape = GradientDrawable().apply {
                        setColor(Color.WHITE)
                        cornerRadius = 28f
                    }
                    val dialog = AlertDialog.Builder(this@MainActivity)
                        .setMessage(message ?: "تأیید می‌کنید؟")
                        .setPositiveButton("تأیید") { _, _ -> result.confirm() }
                        .setNegativeButton("لغو") { _, _ -> result.cancel() }
                        .create()
                    dialog.setOnShowListener {
                        dialog.window?.setBackgroundDrawable(shape)
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.rgb(18, 105, 88))
                        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)?.setTextColor(Color.rgb(100, 100, 100))
                    }
                    dialog.setOnCancelListener { result.cancel() }
                    dialog.show()
                    return true
                }
            }
        }
        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
