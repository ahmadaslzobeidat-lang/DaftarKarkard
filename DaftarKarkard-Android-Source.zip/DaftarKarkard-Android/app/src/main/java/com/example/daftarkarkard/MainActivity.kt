package com.example.daftarkarkard

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var assetLoader: WebViewAssetLoader

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.rgb(18, 59, 53)
        window.navigationBarColor = Color.rgb(18, 59, 53)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.rgb(243, 246, 245))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.databaseEnabled = true

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(
                    view: WebView?,
                    request: android.webkit.WebResourceRequest?
                ): android.webkit.WebResourceResponse? {
                    return request?.url?.let { assetLoader.shouldInterceptRequest(it) }
                }
            }

            webChromeClient = object : WebChromeClient() {
                private fun roundedDialog(
                    message: String?,
                    positive: String,
                    negative: String? = null,
                    onPositive: () -> Unit,
                    onNegative: (() -> Unit)? = null
                ): AlertDialog {
                    val dialog = AlertDialog.Builder(this@MainActivity)
                        .setMessage(message ?: "")
                        .setPositiveButton(positive) { _, _ -> onPositive() }
                        .apply {
                            if (negative != null) {
                                setNegativeButton(negative) { _, _ -> onNegative?.invoke() }
                            }
                        }
                        .create()

                    dialog.setOnShowListener {
                        val background = GradientDrawable().apply {
                            setColor(Color.WHITE)
                            cornerRadius = 32f
                        }
                        dialog.window?.setBackgroundDrawable(background)
                        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
                            ?.setTextColor(Color.rgb(18, 105, 88))
                        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
                            ?.setTextColor(Color.rgb(100, 100, 100))
                    }
                    return dialog
                }

                override fun onJsAlert(
                    view: WebView?, url: String?, message: String?, result: JsResult
                ): Boolean {
                    val dialog = roundedDialog(
                        message = message,
                        positive = "تأیید",
                        onPositive = { result.confirm() }
                    )
                    dialog.setOnCancelListener { result.cancel() }
                    dialog.show()
                    return true
                }

                override fun onJsConfirm(
                    view: WebView?, url: String?, message: String?, result: JsResult
                ): Boolean {
                    val dialog = roundedDialog(
                        message = message,
                        positive = "تأیید",
                        negative = "لغو",
                        onPositive = { result.confirm() },
                        onNegative = { result.cancel() }
                    )
                    dialog.setOnCancelListener { result.cancel() }
                    dialog.show()
                    return true
                }
            }
        }

        setContentView(webView)
        if (savedInstanceState == null) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
